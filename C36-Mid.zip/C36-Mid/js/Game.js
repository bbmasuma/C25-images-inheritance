class Game 
{
  constructor(){}
  

  //Reading the gameState from the database
  getState(){
    var gameStateRef  = database.ref('gameState');
    gameStateRef.on("value",function(data){
       gameState = data.val();
    })
   
  }

  //Writing the updated gameState
  update(state){
    database.ref('/').update({
      gameState: state
    });
  }

  //If game state is 0 (start) adding the players in the game and displaying the forms
  start(){
    if(gameState === 0){
      player = new Player();
      player.getCount();
      form = new Form()
      form.display();
    }
  }
}
