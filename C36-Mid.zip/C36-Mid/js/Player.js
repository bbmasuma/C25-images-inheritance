class Player {
  constructor(){}

  //Reading the number of players in the game from the databse
  getCount(){
    var playerCountRef = database.ref('playerCount');
    playerCountRef.on("value",function(data){
      playerCount = data.val();
    })
  }

  //Writing the count of the players in the databse
  updateCount(count){
    database.ref('/').update({
      playerCount: count
    });
  }


  //Writing the name of the player in the database
  update(name){
    var playerIndex = "player" + playerCount;
    database.ref(playerIndex).set({
      name:name
    });
  }
}
