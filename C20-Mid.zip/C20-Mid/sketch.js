
var fixedRect, movingRect;

function setup() {
  createCanvas(800,800);
  fixedRect= createSprite(600,400,50,80);
  movingRect= createSprite(400,200,80,30);

  fixedRect.shapeColor="green";
  movingRect.shapeColor="green";

  fixedRect.debug=true;
  movingRect.debug=true;
}

function draw() {
  background(255,255,255);  


  movingRect.x=World.mouseX;
  movingRect.y=World.mouseY;


  drawSprites();
}